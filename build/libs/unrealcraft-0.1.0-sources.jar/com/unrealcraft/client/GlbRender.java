package com.unrealcraft.client;

import com.unrealcraft.Unrealcraft;
import javax.imageio.ImageIO;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.util.Locale;

public final class GlbRender {
    private GlbRender() {}

    public static final class Prepared {
        final GlbMesh mesh;
        final class_2960 fallback;
        final class_2960[] textures;
        final int[][] groups;

        Prepared(GlbMesh mesh, class_2960 fallback, class_2960[] textures, int[][] groups) {
            this.mesh = mesh;
            this.fallback = fallback;
            this.textures = textures;
            this.groups = groups;
        }
    }

    public static Prepared prepare(String key, GlbMesh mesh, class_2960 fallback) {
        int n = mesh.images != null ? mesh.images.size() : 0;
        class_2960[] textures = new class_2960[n];
        for (int i = 0; i < n; i++) {
            textures[i] = register(key, i, mesh.images.get(i));
        }
        int tris = mesh.triangleCount();
        int[] counts = new int[n + 1];
        int[] groupOf = new int[tris];
        for (int t = 0; t < tris; t++) {
            int img = (mesh.triImage != null && t < mesh.triImage.length) ? mesh.triImage[t] : -1;
            int g = (img >= 0 && img < n && textures[img] != null) ? img + 1 : 0;
            groupOf[t] = g;
            counts[g]++;
        }
        int[][] groups = new int[counts.length][];
        int[] fill = new int[counts.length];
        for (int g = 0; g < groups.length; g++) groups[g] = new int[counts[g]];
        for (int t = 0; t < tris; t++) groups[groupOf[t]][fill[groupOf[t]]++] = t;
        return new Prepared(mesh, fallback, textures, groups);
    }

    private static class_2960 register(String key, int index, byte[] data) {
        if (data == null || data.length < 8) return null;
        try {
            BufferedImage img = ImageIO.read(new ByteArrayInputStream(data));
            if (img == null) return null;
            class_1011 out = new class_1011(class_1011.class_1012.field_4997, img.getWidth(), img.getHeight(), false);
            for (int y = 0; y < img.getHeight(); y++) {
                for (int x = 0; x < img.getWidth(); x++) {
                    int argb = img.getRGB(x, y);
                    int a = argb >>> 24, r = (argb >> 16) & 255, g = (argb >> 8) & 255, b = argb & 255;
                    out.method_4305(x, y, (a << 24) | (b << 16) | (g << 8) | r);
                }
            }
            class_2960 id = class_2960.method_60655(Unrealcraft.MOD_ID,
                    "dyn/" + key.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9/._-]", "_") + "/" + index);
            class_310.method_1551().method_1531().method_4616(id, new class_1043(out));
            return id;
        } catch (Exception e) {
            return null;
        }
    }

    public static void draw(Prepared p, class_4587.class_4665 entry, class_4597 consumers, int overlay, int light) {
        GlbMesh m = p.mesh;
        if (m.pos == null || m.pos.length < 9) return;
        for (int g = 0; g < p.groups.length; g++) {
            int[] tris = p.groups[g];
            if (tris.length == 0) continue;
            class_2960 texture = g == 0 ? p.fallback : p.textures[g - 1];
            if (texture == null) texture = p.fallback;
            if (texture == null) continue;
            class_4588 vc = consumers.getBuffer(class_1921.method_23578(texture));
            for (int t : tris) {
                for (int k = 0; k < 4; k++) {
                    int v = t * 3 + Math.min(k, 2);
                    int pi = v * 3, ui = v * 2;
                    if (pi + 2 >= m.pos.length) continue;
                    float u = (m.uv != null && ui + 1 < m.uv.length) ? m.uv[ui] : 0f;
                    float vv = (m.uv != null && ui + 1 < m.uv.length) ? m.uv[ui + 1] : 0f;
                    float nx = (m.nrm != null && pi + 2 < m.nrm.length) ? m.nrm[pi] : 0f;
                    float ny = (m.nrm != null && pi + 2 < m.nrm.length) ? m.nrm[pi + 1] : 1f;
                    float nz = (m.nrm != null && pi + 2 < m.nrm.length) ? m.nrm[pi + 2] : 0f;
                    vc.method_56824(entry, m.pos[pi], m.pos[pi + 1], m.pos[pi + 2])
                            .method_1336(255, 255, 255, 255)
                            .method_22913(u, vv)
                            .method_22922(overlay)
                            .method_60803(light)
                            .method_60831(entry, nx, ny, nz);
                }
            }
        }
    }
}
