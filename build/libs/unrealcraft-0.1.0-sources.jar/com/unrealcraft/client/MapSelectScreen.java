package com.unrealcraft.client;

import com.unrealcraft.map.MapInfo;
import com.unrealcraft.map.MapRegistry;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/** Simple map picker — open with K. */
public class MapSelectScreen extends class_437 {
    private final class_437 parent;
    private List<MapInfo> maps = List.of();
    private int scroll;

    public MapSelectScreen(class_437 parent) {
        super(class_2561.method_43470("Unrealcraft Maps"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        MapRegistry.reload();
        maps = MapRegistry.all();
        scroll = 0;
        int y = field_22790 - 28;
        method_37063(class_4185.method_46430(class_2561.method_43470("Close"), b -> method_25419())
                .method_46434(field_22789 / 2 - 50, y, 100, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Reload list"), b -> {
            MapRegistry.reload();
            maps = MapRegistry.all();
        }).method_46434(field_22789 / 2 - 160, y, 100, 20).method_46431());
    }

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        method_25420(ctx, mouseX, mouseY, delta);
        ctx.method_27534(field_22793, field_22785, field_22789 / 2, 12, 0xFFFFFF);
        ctx.method_27534(field_22793,
                class_2561.method_43470("Click a map to /ue map load  ·  Hotkey: K"),
                field_22789 / 2, 28, 0xAAAAAA);

        int top = 48;
        int rowH = 22;
        int visible = Math.max(1, (field_22790 - 90) / rowH);
        for (int i = 0; i < visible && scroll + i < maps.size(); i++) {
            MapInfo m = maps.get(scroll + i);
            int y = top + i * rowH;
            boolean hover = mouseX >= field_22789 / 2 - 160 && mouseX <= field_22789 / 2 + 160
                    && mouseY >= y && mouseY <= y + rowH - 2;
            int bg = hover ? 0x8844AAFF : 0x66000000;
            ctx.method_25294(field_22789 / 2 - 160, y, field_22789 / 2 + 160, y + rowH - 2, bg);
            String tag = m.fromAssets() ? " §7[asset]" : " §8[" + m.format() + "]";
            ctx.method_27535(field_22793,
                    class_2561.method_43470("§e" + m.id() + "§r — " + m.displayName() + tag),
                    field_22789 / 2 - 150, y + 6, 0xFFFFFF);
        }
        super.method_25394(ctx, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        int top = 48;
        int rowH = 22;
        int visible = Math.max(1, (field_22790 - 90) / rowH);
        for (int i = 0; i < visible && scroll + i < maps.size(); i++) {
            int y = top + i * rowH;
            if (mouseX >= field_22789 / 2 - 160 && mouseX <= field_22789 / 2 + 160
                    && mouseY >= y && mouseY <= y + rowH - 2) {
                MapInfo m = maps.get(scroll + i);
                if (field_22787 != null && field_22787.field_1724 != null) {
                    field_22787.field_1724.field_3944.method_45730("ue map load " + m.id());
                }
                method_25419();
                return true;
            }
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horiz, double vert) {
        if (vert > 0) scroll = Math.max(0, scroll - 1);
        else if (vert < 0) scroll = Math.min(Math.max(0, maps.size() - 1), scroll + 1);
        return true;
    }

    @Override
    public void method_25419() {
        if (field_22787 != null) field_22787.method_1507(parent);
    }
}
