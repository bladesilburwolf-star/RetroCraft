package com.unrealcraft.client.retro;

import com.unrealcraft.entity.Sm64MobEntity;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5617;
import net.minecraft.class_7833;
import net.minecraft.class_897;

/** Box-body renderer keyed by Sm64MobEntity.kind — matches Sm64EnemyRenderer colours. */
public class Sm64MobRenderer extends class_897<Sm64MobEntity> {
    private static final class_2960 WHITE = class_2960.method_60656("textures/block/white_concrete.png");

    public Sm64MobRenderer(class_5617.class_5618 ctx) {
        super(ctx);
        this.field_4673 = 0.4f;
    }

    @Override
    public class_2960 getTexture(Sm64MobEntity entity) {
        return WHITE;
    }

    @Override
    public void render(Sm64MobEntity e, float yaw, float tickDelta, class_4587 ms,
                       class_4597 vcp, int light) {
        ms.method_22903();
        ms.method_22907(class_7833.field_40716.rotationDegrees(-yaw));
        class_4588 vc = vcp.getBuffer(class_1921.method_23578(WHITE));
        float[] c = colour(e.getKind());
        float[] s = size(e.getKind());
        box(ms.method_23760(), vc, 0, s[1] * 0.5f, 0, s[0] * 0.5f, s[1], s[0] * 0.5f,
                (int) c[0], (int) c[1], (int) c[2], light);
        // eye
        box(ms.method_23760(), vc, 0, s[1] * 0.7f, s[0] * 0.35f, 0.08f, 0.1f, 0.05f, 255, 255, 255, light);
        ms.method_22909();
        super.method_3936(e, yaw, tickDelta, ms, vcp, light);
    }

    private static float[] colour(String kind) {
        return switch (kind) {
            case "goomba" -> new float[]{140, 90, 40};
            case "koopa" -> new float[]{50, 160, 50};
            case "bobomb", "king_bobomb" -> new float[]{30, 30, 30};
            case "bully", "big_bully" -> new float[]{180, 40, 40};
            case "boo", "big_boo" -> new float[]{230, 230, 255};
            case "whomp" -> new float[]{160, 150, 140};
            case "thwomp" -> new float[]{100, 100, 180};
            case "piranha" -> new float[]{40, 160, 40};
            case "chain_chomp" -> new float[]{40, 40, 40};
            case "bowser" -> new float[]{200, 120, 30};
            case "fly_guy" -> new float[]{200, 40, 40};
            case "lakitu" -> new float[]{220, 220, 80};
            case "chuckya" -> new float[]{200, 80, 160};
            case "amp" -> new float[]{255, 255, 80};
            case "mr_i" -> new float[]{240, 240, 240};
            default -> new float[]{200, 100, 200};
        };
    }

    private static float[] size(String kind) {
        return switch (kind) {
            case "whomp", "thwomp" -> new float[]{1.4f, 2.2f};
            case "bowser", "king_bobomb", "big_bully", "big_boo" -> new float[]{1.6f, 2.4f};
            case "chain_chomp" -> new float[]{1.2f, 1.2f};
            case "koopa", "chuckya" -> new float[]{0.7f, 1.2f};
            default -> new float[]{0.6f, 0.9f};
        };
    }

    private static void box(class_4587.class_4665 en, class_4588 vc,
                            float cx, float cy, float cz, float hx, float hy, float hz,
                            int r, int g, int b, int light) {
        float x0 = cx - hx, x1 = cx + hx;
        float y0 = cy - hy * 0.5f, y1 = cy + hy * 0.5f;
        float z0 = cz - hz, z1 = cz + hz;
        face(en, vc, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, r, g, b, light);
        face(en, vc, x1, y0, z0, x0, y0, z0, x0, y1, z0, x1, y1, z0, r, g, b, light);
        face(en, vc, x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0, r, g, b, light);
        face(en, vc, x1, y0, z1, x1, y0, z0, x1, y1, z0, x1, y1, z1, r, g, b, light);
        face(en, vc, x0, y1, z1, x1, y1, z1, x1, y1, z0, x0, y1, z0, r, g, b, light);
        face(en, vc, x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1, r, g, b, light);
    }

    private static void face(class_4587.class_4665 en, class_4588 vc,
                             float x0, float y0, float z0, float x1, float y1, float z1,
                             float x2, float y2, float z2, float x3, float y3, float z3,
                             int r, int g, int b, int light) {
        v(en, vc, x0, y0, z0, r, g, b, light); v(en, vc, x1, y1, z1, r, g, b, light);
        v(en, vc, x2, y2, z2, r, g, b, light); v(en, vc, x2, y2, z2, r, g, b, light);
        v(en, vc, x0, y0, z0, r, g, b, light); v(en, vc, x2, y2, z2, r, g, b, light);
        v(en, vc, x3, y3, z3, r, g, b, light); v(en, vc, x3, y3, z3, r, g, b, light);
    }

    private static void v(class_4587.class_4665 en, class_4588 vc, float x, float y, float z,
                          int r, int g, int b, int light) {
        vc.method_56824(en, x, y, z).method_1336(r, g, b, 255).method_22913(0f, 0f)
                .method_22922(class_4608.field_21444).method_60803(light).method_60831(en, 0, 1, 0);
    }
}
