package com.unrealcraft.client.retro;

import com.unrealcraft.Unrealcraft;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_243;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5498;
import org.lwjgl.glfw.GLFW;

/**
 * Mario mode: the client player is driven by the ported SM64 physics (30 FPS, stepped 3 frames per 2 client ticks)
 * on the loaded SM64 level. Toggle with the M key (asks the server, which removes the barrier blocks that would
 * otherwise fight the movement). Keys: WASD = stick, Space = A (jump), Shift = Z (crouch / long jump / ground pound), Ctrl/Sprint = B (dive). Mouse turns the camera.
 */
public final class MarioClient {
    private static class_304 toggleKey;
    private static boolean enabled;
    private static RetroMapClient.Active level;
    private static float frameAcc;

    private MarioClient() {}

    public static void init() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new class_304("key.unrealcraft.mario",
                class_3675.class_307.field_1668, GLFW.GLFW_KEY_M, "key.categories.misc"));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.method_1436()) {
                if (client.field_1724 != null) client.field_1724.field_3944.method_45730("sm64 mario");
            }
            if (enabled && client.field_1755 == null) tick(client);
        });
    }

    public static boolean isEnabled() { return enabled; }
    public static String actionName() { return LibSm64Runtime.actionName(); }

    /** Called when the server confirms Mario mode on/off, or when the map goes away. */
    public static void setEnabled(boolean on) {
        class_310 mc = class_310.method_1551();
        if (!on) {
            enabled = false;
            LibSm64Runtime.stop();
            if (mc.field_1724 != null) mc.field_1724.method_5648(false);
            return;
        }
        RetroMapClient.Active a = RetroMapClient.sm64();
        if (a == null || mc.field_1724 == null) return;
        RetroMapClient.prepare(a);
        if (a.mesh == null || a.sm64 == null) return;
        LibSm64Runtime.stop();
        if (!LibSm64Runtime.start(mc, a)) return;
        level = a;
        frameAcc = 0f;
        enabled = true;
        mc.field_1724.method_5648(true);
        mc.field_1690.method_31043(class_5498.field_26665);
        Unrealcraft.LOGGER.info("Native libsm64 Mario mode enabled for {}", a.path);
    }

    private static void tick(class_310 mc) {
        if (mc.field_1724 == null || mc.field_1687 == null || RetroMapClient.sm64() != level) {
            setEnabled(false);
            return;
        }
        frameAcc += 1.5f; // 30 SM64 frames per second over 20 client ticks per second
        int frames = (int) frameAcc;
        frameAcc -= frames;
        LibSm64Runtime.tick(mc, level, frames);
    }

    /** Draw libsm64's animated triangle mesh at the player position. */
    public static void render(class_4587 ms, class_4597 vcp, class_243 cam) {
        class_310 mc = class_310.method_1551();
        if (!enabled || mc.field_1724 == null) return;
        float delta = mc.method_60646().method_60637(false);
        class_243 p = mc.field_1724.method_30950(delta);
        LibSm64Runtime.render(ms, vcp, cam, p);
    }
}
