package com.unrealcraft.client.retro;

import com.unrealcraft.Unrealcraft;
import com.unrealcraft.sm64.Sm64Png;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2960;
import net.minecraft.class_310;

/** Loads textures extracted from the SM64 ROM (PNG files in the decomp tree) into Minecraft's texture manager. */
public final class Sm64Textures {
    private static final Map<String, class_2960> CACHE = new HashMap<>();

    private Sm64Textures() {}

    /** @return the texture id, or null when the PNG has not been extracted / cannot be read. */
    public static class_2960 get(Path root, String rel) {
        String key = root + "|" + rel;
        if (CACHE.containsKey(key)) return CACHE.get(key);
        class_2960 id = null;
        Path p = root.resolve(rel);
        if (Files.isRegularFile(p)) {
            try {
                Sm64Png png = Sm64Png.read(p);
                class_1011 img = new class_1011(class_1011.class_1012.field_4997, png.width, png.height, false);
                for (int y = 0; y < png.height; y++) for (int x = 0; x < png.width; x++) {
                    int c = png.argb[y * png.width + x];
                    int a = c >>> 24, r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
                    img.method_4305(x, y, (a << 24) | (b << 16) | (g << 8) | r); // NativeImage stores ABGR
                }
                class_1043 tex = new class_1043(img);
                id = Unrealcraft.id("sm64/" + Integer.toHexString(key.hashCode()) + "_" + CACHE.size());
                class_310.method_1551().method_1531().method_4616(id, tex);
            } catch (Exception e) {
                Unrealcraft.LOGGER.warn("SM64 texture failed {}: {}", p, e.toString());
            }
        } else {
            Unrealcraft.LOGGER.warn("SM64 texture missing (extract your ROM assets first): {}", p);
        }
        CACHE.put(key, id);
        return id;
    }
}
