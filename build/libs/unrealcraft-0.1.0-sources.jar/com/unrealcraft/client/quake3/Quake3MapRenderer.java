package com.unrealcraft.client.quake3;

import com.unrealcraft.entity.Quake3MapEntity;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4604;
import net.minecraft.class_5617;
import net.minecraft.class_897;

/** Legacy entity from older saves. Q3 maps are now drawn by RetroMapClient; this renders nothing. */
public final class Quake3MapRenderer extends class_897<Quake3MapEntity> {
    public Quake3MapRenderer(class_5617.class_5618 c) { super(c); field_4673 = 0; }

    @Override
    public boolean shouldRender(Quake3MapEntity e, class_4604 f, double x, double y, double z) { return false; }

    @Override
    public void render(Quake3MapEntity e, float yaw, float tick, class_4587 ms, class_4597 vcp, int light) {}

    @Override
    public class_2960 getTexture(Quake3MapEntity e) { return class_2960.method_60656("textures/block/stone.png"); }
}
