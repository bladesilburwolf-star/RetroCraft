package com.unrealcraft.client.halflife;

import com.unrealcraft.Unrealcraft;
import com.unrealcraft.halflife.HalfLifeBsp;
import java.util.*;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2960;
import net.minecraft.class_310;

public final class HalfLifeTextures {
    private static final Map<String,class_2960> CACHE=new HashMap<>();
    private static HalfLifeBsp bsp;
    private static class_2960 fallback(){return class_2960.method_60656("textures/block/stone.png");}
    public static void setBsp(HalfLifeBsp b){bsp=b;CACHE.clear();}
    public static class_2960 get(String name){if(name==null||name.isBlank())return fallback();String k=name.toUpperCase(Locale.ROOT);class_2960 old=CACHE.get(k);if(old!=null)return old;if(bsp==null)return fallback();int idx=bsp.textureNames.indexOf(k);if(idx<0)return fallback();HalfLifeWadProxy t=new HalfLifeWadProxy(bsp.texture(idx));if(t.valid()){class_2960 id=register(k,t.w,t.h,t.px);CACHE.put(k,id);return id;}return fallback();}
    private static class_2960 register(String n,int w,int h,int[] px){try{class_1011 img=new class_1011(class_1011.class_1012.field_4997,w,h,false);for(int y=0;y<h;y++)for(int x=0;x<w;x++){int c=px[y*w+x];img.method_4305(x,y,((c>>>24)&255)<<24|((c>>0)&255)<<16|((c>>8)&255)<<8|((c>>16)&255));}class_2960 id=class_2960.method_60655(Unrealcraft.MOD_ID,"hl1/"+n.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_]","_"));class_310.method_1551().method_1531().method_4616(id,new class_1043(img));return id;}catch(Exception e){Unrealcraft.LOGGER.warn("HL1 texture {} failed",n,e);return fallback();}}
    private record HalfLifeWadProxy(int w,int h,int[] px){HalfLifeWadProxy(com.unrealcraft.halflife.HalfLifeWad.Texture t){this(t==null?0:t.width(),t==null?0:t.height(),t==null?new int[0]:t.argb());}boolean valid(){return w>0&&h>0&&px.length==w*h;}}
}
