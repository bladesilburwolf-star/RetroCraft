package com.unrealcraft.client.halflife;

import com.unrealcraft.Unrealcraft;
import com.unrealcraft.config.UnrealConfig;
import com.unrealcraft.entity.HalfLifeMapEntity;
import com.unrealcraft.halflife.HalfLifeBsp;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4604;
import net.minecraft.class_4608;
import net.minecraft.class_5617;
import net.minecraft.class_897;
import java.util.List;
import java.util.ArrayList;

public final class HalfLifeMapRenderer extends class_897<HalfLifeMapEntity> {
    private final Map<String, HalfLifeMapMesh> cache=new HashMap<>();
    private final Map<String, HalfLifeBsp> bsps=new HashMap<>();
    public HalfLifeMapRenderer(class_5617.class_5618 ctx){super(ctx);field_4673=0;}
    private HalfLifeMapMesh meshFor(String path){
        if(path==null||path.isBlank())return null; if(cache.containsKey(path))return cache.get(path);
        try{
            UnrealConfig c=UnrealConfig.get(); Path bsp=Path.of(path); List<Path> wads=wadPaths(c.hl1WadPath);
            HalfLifeBsp b=HalfLifeBsp.load(bsp,wads); bsps.put(path,b); HalfLifeTextures.setBsp(b);
            HalfLifeMapMesh m=HalfLifeMapMesh.build(b,c.hl1UnitsPerBlock); cache.put(path,m); Unrealcraft.LOGGER.info("HL1 mesh {}: {} triangles",bsp.getFileName(),m.tris.size()); return m;
        }catch(Exception e){Unrealcraft.LOGGER.error("HL1 BSP load failed {}",path,e);return null;}
    }
    private List<Path> wadPaths(String configured){
        if(configured==null||configured.isBlank()) return List.of();
        List<Path> out=new ArrayList<>();
        for(String s:configured.split(";")){
            if(s==null||s.isBlank()) continue;
            Path p=Path.of(s.trim());
            if(p.toFile().isFile()) out.add(p);
        }
        return out;
    }
    @Override public boolean shouldRender(HalfLifeMapEntity e,class_4604 f,double x,double y,double z){return true;}
    @Override public void render(HalfLifeMapEntity entity,float yaw,float tickDelta,class_4587 matrices,class_4597 consumers,int light){
        HalfLifeMapMesh mesh=meshFor(entity.getBspPath()); if(mesh==null||mesh.tris.isEmpty())return; matrices.method_22903();
        for(var entry:mesh.byTexture().entrySet()){
            class_2960 tex=HalfLifeTextures.get(entry.getKey()); class_4588 vc=consumers.getBuffer(class_1921.method_23578(tex)); class_4587.class_4665 en=matrices.method_23760();
            for(HalfLifeMapMesh.Tri t:entry.getValue())for(int i=0;i<3;i++){int p=i*3,u=i*2;vc.method_56824(en,t.pos()[p],t.pos()[p+1],t.pos()[p+2]).method_1336(255,255,255,255).method_22913(t.uv()[u],1-t.uv()[u+1]).method_22922(class_4608.field_21444).method_60803(0xF000F0).method_60831(en,0,1,0);}
        } matrices.method_22909();
    }
    @Override public class_2960 getTexture(HalfLifeMapEntity e){return class_2960.method_60656("textures/block/stone.png");}
}
