package com.unrealcraft;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.unrealcraft.config.UnrealConfig;
import com.unrealcraft.net.RetroMapPayload;
import com.unrealcraft.net.RetroMapServer;
import com.unrealcraft.quake3.Quake3Collision;
import com.unrealcraft.sm64.Sm64Level;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * /sm64 dir &lt;path-to-sm64-clone&gt;   - remember where your n64decomp/sm64 clone lives
 * /sm64 load &lt;level&gt; [area]       - e.g. /sm64 load bob   or   /sm64 load castle_grounds 1
 * /sm64 unload
 * Level collision is read from the decomp source tree; same placement rules as Quake 3 maps
 * (lowest point at mapSeaY, Mario's start at the player's X/Z, player moved onto the start).
 */
public final class Sm64MapLoader {
    private static final List<class_2338> COLLISION = new ArrayList<>();
    // last loaded level, kept so barrier collision can be rebuilt when leaving Mario mode
    private static com.unrealcraft.sm64.Sm64Level.Result lastRes;
    private static com.unrealcraft.quake3.Quake3Bsp.Placement lastPl;
    private static class_2338 lastOrigin;
    private static boolean marioOn;

    private Sm64MapLoader() {}

    public static void init() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registry, env) -> {
            var root = class_2170.method_9247("sm64");
            root.then(class_2170.method_9247("dir")
                    .then(class_2170.method_9244("path", StringArgumentType.string()).executes(c -> {
                        UnrealConfig.get().sm64Dir = StringArgumentType.getString(c, "path");
                        UnrealConfig.save();
                        c.getSource().method_9226(() -> class_2561.method_43470("SM64 source dir set to " + UnrealConfig.get().sm64Dir), false);
                        return 1;
                    })));
            root.then(class_2170.method_9247("load")
                    .then(class_2170.method_9244("level", StringArgumentType.word())
                            .executes(c -> load(c.getSource(), StringArgumentType.getString(c, "level"), 1))
                            .then(class_2170.method_9244("area", IntegerArgumentType.integer(1, 13))
                                    .executes(c -> load(c.getSource(), StringArgumentType.getString(c, "level"),
                                            IntegerArgumentType.getInteger(c, "area"))))));
            root.then(class_2170.method_9247("mario").executes(c -> toggleMario(c.getSource())));
            root.then(class_2170.method_9247("unload").executes(c -> {
                clear(c.getSource().method_9225());
                return 1;
            }));
            dispatcher.register(root);
        });
    }

    public static int load(class_2168 src, String level, int area) {
        class_3218 w = src.method_9225();
        Quake3MapLoader.clear(w);
        clear(w);
        UnrealConfig cfg = UnrealConfig.get();
        if (cfg.sm64Dir == null || cfg.sm64Dir.isBlank()) {
            src.method_9213(class_2561.method_43470("Set your SM64 decomp clone first: /sm64 dir \"C:/path/to/sm64\""));
            return 0;
        }
        if (!level.matches("[a-z0-9_]+")) {
            src.method_9213(class_2561.method_43470("Bad level name: " + level));
            return 0;
        }
        Path levelDir = Path.of(cfg.sm64Dir.trim()).resolve("levels").resolve(level);
        if (!Files.isDirectory(levelDir)) {
            src.method_9213(class_2561.method_43470("Level folder not found: " + levelDir));
            return 0;
        }
        try {
            float upb = cfg.sm64UnitsPerBlock;
            var res = Sm64Level.load(levelDir, area, upb);
            if (res.tris().isEmpty()) {
                src.method_9213(class_2561.method_43470("No collision triangles in " + level + " area " + area));
                return 0;
            }
            var pl = Sm64Level.placement(res, upb);
            var pos = src.method_9222();
            int sea = cfg.mapSeaY;
            int ax = (int) Math.floor(pos.field_1352), az = (int) Math.floor(pos.field_1350);
            class_2338 origin = new class_2338(ax, sea, az);

            lastRes = res; lastPl = pl; lastOrigin = origin;
            int placed = (cfg.buildCollision && !marioOn) ? buildCollision(w) : 0;

            RetroMapServer.show(w.method_8503(), new RetroMapPayload("load", "sm64",
                    levelDir.toAbsolutePath() + "|" + area, ax, sea, az));

            class_3222 player = src.method_44023();
            if (player != null && pl.hasSpawn()) {
                player.method_5859(ax + 0.5, sea + pl.spawnFeetLocalY() + 0.05, az + 0.5);
            }
            final int fPlaced = placed;
            src.method_9226(() -> class_2561.method_43470(String.format(
                    "SM64 §e%s§r area %d: %d tris, anchor (%d, %d, %d), %d collision blocks%s",
                    level, area, res.tris().size(), ax, sea, az, fPlaced,
                    pl.hasSpawn() ? ", moved to Mario's start" : ", no start point (centred)")), false);
            Unrealcraft.LOGGER.info("SM64 loaded {} area {} tris={} placement={}", level, area, res.tris().size(), pl);
            return 1;
        } catch (Exception e) {
            Unrealcraft.LOGGER.error("SM64 load failed", e);
            src.method_9213(class_2561.method_43470("SM64 load failed: " + e.getMessage()));
            return 0;
        }
    }

    private static int buildCollision(class_3218 w) {
        UnrealConfig cfg = UnrealConfig.get();
        int placed = 0;
        for (int[] v : Quake3Collision.voxels(lastRes.tris(), lastPl, cfg.collisionBlockLimit)) {
            class_2338 bp = lastOrigin.method_10069(v[0], v[1], v[2]);
            if (w.method_31606(bp)) continue;
            w.method_8652(bp, class_2246.field_10499.method_9564(), class_2248.field_31028);
            COLLISION.add(bp);
            placed++;
        }
        return placed;
    }

    private static void removeCollision(class_3218 w) {
        for (class_2338 p : COLLISION) w.method_8652(p, class_2246.field_10124.method_9564(), class_2248.field_31028);
        COLLISION.clear();
    }

    /** /sm64 mario: drive the player with the ported SM64 physics (barrier blocks are removed while it is on). */
    private static int toggleMario(class_2168 src) {
        class_3218 w = src.method_9225();
        if (lastRes == null) {
            src.method_9213(class_2561.method_43470("Load an SM64 level first: /sm64 load bob"));
            return 0;
        }
        marioOn = !marioOn;
        if (marioOn) removeCollision(w);
        else if (UnrealConfig.get().buildCollision) buildCollision(w);
        RetroMapServer.send(w.method_8503(), new RetroMapPayload("mario", "sm64", marioOn ? "on" : "off", 0, 0, 0));
        final boolean on = marioOn;
        src.method_9226(() -> class_2561.method_43470(on
                ? "Mario mode ON  (WASD move, Space = A jump, Shift = Z, mouse = camera, M = off)"
                : "Mario mode OFF"), false);
        return 1;
    }

    public static void clear(class_3218 w) {
        RetroMapServer.hide(w.method_8503(), "sm64");
        removeCollision(w);
        lastRes = null; lastPl = null; lastOrigin = null; marioOn = false;
    }
}
