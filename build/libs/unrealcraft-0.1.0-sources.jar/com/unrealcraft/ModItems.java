package com.unrealcraft;

import com.unrealcraft.item.Sm64SpawnEggItem;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Creative tab + SM64 enemy spawn eggs.
 * Open creative → Unrealcraft tab → place goombas, koopas, etc. by hand.
 */
public class ModItems {
    public static final Map<String, class_1792> SPAWN_EGGS = new LinkedHashMap<>();

    private static final String[] KINDS = {
            "goomba", "koopa", "bobomb", "bully", "big_bully",
            "boo", "big_boo", "whomp", "thwomp", "piranha",
            "chain_chomp", "fly_guy", "lakitu", "chuckya", "amp",
            "mr_i", "king_bobomb", "bowser"
    };

    public static void register() {
        for (String kind : KINDS) {
            String id = "spawn_" + kind;
            class_5321<class_1792> key = class_5321.method_29179(class_7924.field_41197, Unrealcraft.id(id));
            class_1792 egg = new Sm64SpawnEggItem(kind, new class_1792.class_1793().method_7889(64));
            class_2378.method_39197(class_7923.field_41178, key, egg);
            SPAWN_EGGS.put(kind, egg);
        }

        class_2378.method_10230(class_7923.field_44687, Unrealcraft.id("main"),
                FabricItemGroup.builder()
                        .method_47320(() -> new class_1799(class_1802.field_8803))
                        .method_47321(class_2561.method_43470("Unrealcraft / SM64"))
                        .method_47317((ctx, entries) -> {
                            for (class_1792 egg : SPAWN_EGGS.values()) entries.method_45421(egg);
                            // native stand-ins for props
                            entries.method_45421(class_1802.field_8691);
                            entries.method_45421(class_1802.field_8594);
                            entries.method_45421(class_1802.field_8788);
                            entries.method_45421(class_1802.field_40229);
                            entries.method_45421(class_1802.field_8397);  // coin stand-in
                            entries.method_45421(class_1802.field_8695);
                            entries.method_45421(class_1802.field_8137); // star stand-in
                            entries.method_45421(class_1802.field_8626);         // bob-omb stand-in / mine
                        })
                        .method_47324());

        Unrealcraft.LOGGER.info("SM64 spawn eggs registered: {}", SPAWN_EGGS.keySet());
    }
}
