package com.unrealcraft;

import com.unrealcraft.client.MapSelectScreen;
import com.unrealcraft.client.UePropRenderer;
import com.unrealcraft.client.halflife.HalfLifeMapRenderer;
import com.unrealcraft.client.quake3.Quake3MapRenderer;
import com.unrealcraft.client.retro.Sm64MobRenderer;
import com.unrealcraft.client.retro.Sm64Collectibles;
import com.unrealcraft.map.MapRegistry;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class UnrealcraftClient implements ClientModInitializer {
    private static class_304 openMapsKey;

    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ModEntities.UE_PROP, UePropRenderer::new);
        EntityRendererRegistry.register(ModEntities.HL1_MAP, HalfLifeMapRenderer::new);
        EntityRendererRegistry.register(ModEntities.Q3_MAP, Quake3MapRenderer::new);
        EntityRendererRegistry.register(ModEntities.SM64_MOB, Sm64MobRenderer::new);
        MapRegistry.reload();
        com.unrealcraft.client.retro.RetroMapClient.init();

        openMapsKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.unrealcraft.maps",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_K,
                "category.unrealcraft"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMapsKey.method_1436()) {
                if (client.field_1724 != null && client.field_1755 == null) {
                    client.method_1507(new MapSelectScreen(null));
                }
            }
            Sm64Collectibles.tick();
        });
    }
}
