package com.unrealcraft;

import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.unrealcraft.config.UnrealConfig;
import com.unrealcraft.entity.UePropEntity;
import com.unrealcraft.map.MapInfo;
import com.unrealcraft.map.MapLoader;
import com.unrealcraft.map.MapRegistry;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public final class PropCommands {
    private PropCommands() {}

    public static void init() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registry, env) -> {
            var root = class_2170.method_9247("ue");

            root.then(class_2170.method_9247("spawn")
                    .then(class_2170.method_9244("model", StringArgumentType.string())
                            .executes(ctx -> spawn(ctx.getSource(),
                                    StringArgumentType.getString(ctx, "model"),
                                    UnrealConfig.get().defaultScale))
                            .then(class_2170.method_9244("scale", FloatArgumentType.floatArg(0.01f, 100f))
                                    .executes(ctx -> spawn(ctx.getSource(),
                                            StringArgumentType.getString(ctx, "model"),
                                            FloatArgumentType.getFloat(ctx, "scale"))))));

            root.then(class_2170.method_9247("reloadconfig")
                    .executes(ctx -> {
                        UnrealConfig.load();
                        MapRegistry.reload();
                        ctx.getSource().method_9226(() -> class_2561.method_43470("Config + map list reloaded"), false);
                        return 1;
                    }));

            root.then(class_2170.method_9247("maps")
                    .executes(ctx -> {
                        MapRegistry.reload();
                        var list = MapRegistry.all();
                        ctx.getSource().method_9226(() -> class_2561.method_43470("Maps (" + list.size() + "):"), false);
                        for (MapInfo m : list) {
                            String where = m.fromAssets() ? " [asset]" : " [file]";
                            ctx.getSource().method_9226(
                                    () -> class_2561.method_43470("  §e" + m.id() + "§r — " + m.displayName() + where), false);
                        }
                        return list.size();
                    }));

            root.then(class_2170.method_9247("map")
                    .then(class_2170.method_9247("list")
                            .executes(ctx -> {
                                MapRegistry.reload();
                                var list = MapRegistry.all();
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Maps (" + list.size() + "):"), false);
                                for (MapInfo m : list) {
                                    ctx.getSource().method_9226(
                                            () -> class_2561.method_43470("  §e" + m.id() + "§r — " + m.displayName()), false);
                                }
                                return list.size();
                            }))
                    .then(class_2170.method_9247("load")
                            .then(class_2170.method_9244("name", StringArgumentType.string())
                                    .executes(ctx -> {
                                        class_3222 p = ctx.getSource().method_44023();
                                        if (p == null) {
                                            ctx.getSource().method_9213(class_2561.method_43470("Players only"));
                                            return 0;
                                        }
                                        String name = StringArgumentType.getString(ctx, "name");
                                        return MapRegistry.find(name)
                                                .map(m -> MapLoader.load(p, m))
                                                .orElseGet(() -> {
                                                    ctx.getSource().method_9213(class_2561.method_43470("Unknown map: " + name));
                                                    return 0;
                                                });
                                    })))
                    .then(class_2170.method_9247("clear")
                            .executes(ctx -> {
                                class_3222 p = ctx.getSource().method_44023();
                                if (p == null) return 0;
                                MapLoader.clear(p.method_51469());
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Cleared loaded map props"), false);
                                return 1;
                            })));

            dispatcher.register(root);
        });
    }

    private static int spawn(class_2168 src, String model, float scale) {
        var world = src.method_9225();
        var pos = src.method_9222();
        UePropEntity e = new UePropEntity(world, model, scale);
        e.method_5808(pos.field_1352, pos.field_1351, pos.field_1350, src.method_9210().field_1342, 0);
        world.method_8649(e);
        src.method_9226(() -> class_2561.method_43470("Spawned UE prop '" + model + "' scale=" + scale), false);
        return 1;
    }
}
