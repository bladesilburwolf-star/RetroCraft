package com.unrealcraft.item;

import com.unrealcraft.ModEntities;
import com.unrealcraft.entity.Sm64MobEntity;
import net.minecraft.class_1269;
import net.minecraft.class_1792;
import net.minecraft.class_1838;
import net.minecraft.class_2338;
import net.minecraft.class_3218;

/** Places an Sm64MobEntity of a fixed kind on right-click. Creative-friendly. */
public class Sm64SpawnEggItem extends class_1792 {
    private final String kind;

    public Sm64SpawnEggItem(String kind, class_1793 settings) {
        super(settings);
        this.kind = kind;
    }

    public String kind() { return kind; }

    @Override
    public class_1269 method_7884(class_1838 ctx) {
        if (ctx.method_8045().field_9236) return class_1269.field_5812;
        class_3218 world = (class_3218) ctx.method_8045();
        class_2338 pos = ctx.method_8037().method_10093(ctx.method_8038());
        Sm64MobEntity mob = ModEntities.SM64_MOB.method_5883(world);
        if (mob == null) return class_1269.field_5814;
        mob.setKind(kind);
        mob.method_5808(pos.method_10263() + 0.5, pos.method_10264(), pos.method_10260() + 0.5,
                ctx.method_8036() != null ? ctx.method_8036().method_36454() : 0f, 0f);
        world.method_8649(mob);
        if (ctx.method_8036() != null && !ctx.method_8036().method_31549().field_7477) {
            ctx.method_8041().method_7934(1);
        }
        return class_1269.field_21466;
    }
}
