package com.unrealcraft.net;

import com.unrealcraft.Unrealcraft;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Server -> client: draw (or clear) an imported map at a world anchor.
 * action = "load" | "clear", kind = "q3" (hl1 / t3d to follow), path = absolute file path readable by the client.
 */
public record RetroMapPayload(String action, String kind, String path, double x, double y, double z)
        implements class_8710 {
    public static final class_9154<RetroMapPayload> ID = new class_9154<>(Unrealcraft.id("retro_map"));
    public static final class_9139<class_9129, RetroMapPayload> CODEC = class_9139.method_58025(
            class_9135.field_48554, RetroMapPayload::action,
            class_9135.field_48554, RetroMapPayload::kind,
            class_9135.field_48554, RetroMapPayload::path,
            class_9135.field_48553, RetroMapPayload::x,
            class_9135.field_48553, RetroMapPayload::y,
            class_9135.field_48553, RetroMapPayload::z,
            RetroMapPayload::new);

    public static RetroMapPayload clear(String kind) { return new RetroMapPayload("clear", kind, "", 0, 0, 0); }

    @Override public class_9154<? extends class_8710> method_56479() { return ID; }
}
