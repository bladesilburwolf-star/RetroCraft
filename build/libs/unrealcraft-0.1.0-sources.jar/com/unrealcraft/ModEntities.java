package com.unrealcraft;

import com.unrealcraft.entity.UePropEntity;
import com.unrealcraft.entity.HalfLifeMapEntity;
import com.unrealcraft.entity.Quake3MapEntity;
import com.unrealcraft.entity.Sm64MobEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class ModEntities {
    public static final class_1299<UePropEntity> UE_PROP = class_2378.method_39197(
            class_7923.field_41177,
            class_5321.method_29179(class_7924.field_41266, Unrealcraft.id("ue_prop")),
            class_1299.class_1300.<UePropEntity>method_5903(UePropEntity::new, class_1311.field_17715)
                    .method_17687(2.0f, 2.0f)
                    .method_27299(256)
                    .method_27300(20)
                    .method_5905("ue_prop"));

    public static final class_1299<HalfLifeMapEntity> HL1_MAP = class_2378.method_39197(
            class_7923.field_41177,
            class_5321.method_29179(class_7924.field_41266, Unrealcraft.id("hl1_map")),
            class_1299.class_1300.<HalfLifeMapEntity>method_5903(HalfLifeMapEntity::new, class_1311.field_17715)
                    .method_17687(2.0f, 2.0f).method_27299(256).method_27300(20).method_5905("hl1_map"));

    public static final class_1299<Quake3MapEntity> Q3_MAP = class_2378.method_39197(
            class_7923.field_41177,
            class_5321.method_29179(class_7924.field_41266, Unrealcraft.id("q3_map")),
            class_1299.class_1300.<Quake3MapEntity>method_5903(Quake3MapEntity::new, class_1311.field_17715)
                    .method_17687(2.0f, 2.0f).method_27299(256).method_27300(20).method_5905("q3_map"));

    public static final class_1299<Sm64MobEntity> SM64_MOB = class_2378.method_39197(
            class_7923.field_41177,
            class_5321.method_29179(class_7924.field_41266, Unrealcraft.id("sm64_mob")),
            class_1299.class_1300.<Sm64MobEntity>method_5903(Sm64MobEntity::new, class_1311.field_6302)
                    .method_17687(0.7f, 1.0f)
                    .method_27299(64)
                    .method_27300(3)
                    .method_5905("sm64_mob"));

    public static void register() {
        FabricDefaultAttributeRegistry.register(SM64_MOB, Sm64MobEntity.createAttributes());
        Unrealcraft.LOGGER.info("Entities registered (incl. sm64_mob)");
    }
}
