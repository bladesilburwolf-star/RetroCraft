package com.unrealcraft.entity;

import com.unrealcraft.ModEntities;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;

/** Marker for one imported GoldSrc BSP. Client renderer draws the complete face mesh. */
public class HalfLifeMapEntity extends class_1297 {
    private static final class_2940<String> BSP_PATH = class_2945.method_12791(HalfLifeMapEntity.class, class_2943.field_13326);
    public HalfLifeMapEntity(class_1299<? extends HalfLifeMapEntity> type, class_1937 world) { super(type, world); field_5960=true; method_5875(true); method_5648(true); field_5985=true; }
    public HalfLifeMapEntity(class_1937 world, String path){this(ModEntities.HL1_MAP,world);setBspPath(path);}
    public String getBspPath(){return field_6011.method_12789(BSP_PATH);}
    public void setBspPath(String path){field_6011.method_12778(BSP_PATH,path==null?"":path);}
    @Override protected void method_5693(class_2945.class_9222 b){b.method_56912(BSP_PATH,"");}
    @Override protected void method_5749(class_2487 n){if(n.method_10545("BspPath"))setBspPath(n.method_10558("BspPath"));}
    @Override protected void method_5652(class_2487 n){n.method_10582("BspPath",getBspPath());}
    @Override public boolean method_5640(double distance){return true;}
}
