package com.unrealcraft.entity;

import com.unrealcraft.ModEntities;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;

public class UePropEntity extends class_1297 {
    private static final class_2940<String> MODEL =
            class_2945.method_12791(UePropEntity.class, class_2943.field_13326);
    private static final class_2940<Float> SCALE =
            class_2945.method_12791(UePropEntity.class, class_2943.field_13320);
    private static final class_2940<Float> QX =
            class_2945.method_12791(UePropEntity.class, class_2943.field_13320);
    private static final class_2940<Float> QY =
            class_2945.method_12791(UePropEntity.class, class_2943.field_13320);
    private static final class_2940<Float> QZ =
            class_2945.method_12791(UePropEntity.class, class_2943.field_13320);
    private static final class_2940<Float> QW =
            class_2945.method_12791(UePropEntity.class, class_2943.field_13320);
    private static final class_2940<Boolean> MAP_MODE =
            class_2945.method_12791(UePropEntity.class, class_2943.field_13323);

    public UePropEntity(class_1299<? extends UePropEntity> type, class_1937 world) {
        super(type, world);
        this.field_5960 = true;
        this.method_5875(true);
        this.method_5684(true);
    }

    public UePropEntity(class_1937 world, String model, float scale) {
        this(ModEntities.UE_PROP, world);
        setModel(model);
        setPropScale(scale);
    }

    public String getModel() { return field_6011.method_12789(MODEL); }
    public void setModel(String m) { field_6011.method_12778(MODEL, m == null ? "" : m); }
    public float getPropScale() { return field_6011.method_12789(SCALE); }
    public void setPropScale(float s) { field_6011.method_12778(SCALE, s); }

    public float getQx() { return field_6011.method_12789(QX); }
    public float getQy() { return field_6011.method_12789(QY); }
    public float getQz() { return field_6011.method_12789(QZ); }
    public float getQw() { return field_6011.method_12789(QW); }

    public void setRotation(float x, float y, float z, float w) {
        field_6011.method_12778(QX, x);
        field_6011.method_12778(QY, y);
        field_6011.method_12778(QZ, z);
        field_6011.method_12778(QW, w);
    }

    /** Euler degrees XYZ → quaternion (intrinsic-ish sequential). */
    public boolean isMapMode() { return field_6011.method_12789(MAP_MODE); }
    public void setMapMode(boolean value) { field_6011.method_12778(MAP_MODE, value); }

    public void setRotationDegrees(float pitchX, float yawY, float rollZ) {
        double rx = Math.toRadians(pitchX) * 0.5;
        double ry = Math.toRadians(yawY) * 0.5;
        double rz = Math.toRadians(rollZ) * 0.5;
        double cx = Math.cos(rx), sx = Math.sin(rx);
        double cy = Math.cos(ry), sy = Math.sin(ry);
        double cz = Math.cos(rz), sz = Math.sin(rz);
        // XYZ order
        float qw = (float) (cx * cy * cz + sx * sy * sz);
        float qx = (float) (sx * cy * cz - cx * sy * sz);
        float qy = (float) (cx * sy * cz + sx * cy * sz);
        float qz = (float) (cx * cy * sz - sx * sy * cz);
        setRotation(qx, qy, qz, qw);
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        builder.method_56912(MODEL, "");
        builder.method_56912(SCALE, 1.0f);
        builder.method_56912(QX, 0f);
        builder.method_56912(QY, 0f);
        builder.method_56912(QZ, 0f);
        builder.method_56912(QW, 1f);
        builder.method_56912(MAP_MODE, false);
    }

    @Override
    protected void method_5749(class_2487 nbt) {
        if (nbt.method_10545("Model")) setModel(nbt.method_10558("Model"));
        if (nbt.method_10545("Scale")) setPropScale(nbt.method_10583("Scale"));
        setRotation(
                nbt.method_10545("Qx") ? nbt.method_10583("Qx") : 0f,
                nbt.method_10545("Qy") ? nbt.method_10583("Qy") : 0f,
                nbt.method_10545("Qz") ? nbt.method_10583("Qz") : 0f,
                nbt.method_10545("Qw") ? nbt.method_10583("Qw") : 1f);
        setMapMode(nbt.method_10545("MapMode") && nbt.method_10577("MapMode"));
    }

    @Override
    protected void method_5652(class_2487 nbt) {
        nbt.method_10582("Model", getModel());
        nbt.method_10548("Scale", getPropScale());
        nbt.method_10548("Qx", getQx());
        nbt.method_10548("Qy", getQy());
        nbt.method_10548("Qz", getQz());
        nbt.method_10548("Qw", getQw());
        nbt.method_10556("MapMode", isMapMode());
    }

    @Override
    public boolean method_5640(double distance) {
        return distance < 512.0 * 512.0;
    }

    @Override
    public boolean method_30948() { return false; }

    @Override
    public boolean method_5863() { return false; }
}
