package com.unrealcraft.entity;

import net.minecraft.class_1299;
import net.minecraft.class_1314;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_5132;
import net.minecraft.class_5134;

/**
 * Placeholder SM64 enemy for Fabric 1.21.1.
 * Kind string drives colour/size in the renderer only.
 *
 * Do NOT override getDimensions(EntityPose) — it is final on LivingEntity in 1.21.1.
 * Hitbox stays at EntityType dimensions (0.7 x 1.0 from ModEntities).
 * No real AI yet — stands still.
 */
public class Sm64MobEntity extends class_1314 {
    private static final class_2940<String> KIND =
            class_2945.method_12791(Sm64MobEntity.class, class_2943.field_13326);

    public Sm64MobEntity(class_1299<? extends class_1314> type, class_1937 world) {
        super(type, world);
        method_5977(true);
        method_5971();
    }

    public static class_5132.class_5133 createAttributes() {
        return class_1314.method_26828()
                .method_26868(class_5134.field_23716, 10.0)
                .method_26868(class_5134.field_23719, 0.25)
                .method_26868(class_5134.field_23717, 16.0)
                .method_26868(class_5134.field_23721, 2.0);
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        super.method_5693(builder);
        builder.method_56912(KIND, "goomba");
    }

    public String getKind() {
        return method_5841().method_12789(KIND);
    }

    public void setKind(String kind) {
        if (kind == null || kind.isEmpty()) kind = "goomba";
        method_5841().method_12778(KIND, kind);
        // Visual scale is handled in Sm64MobRenderer by kind; hitbox stays EntityType default.
    }

    @Override
    public void method_5652(class_2487 nbt) {
        super.method_5652(nbt);
        nbt.method_10582("Sm64Kind", getKind());
    }

    @Override
    public void method_5749(class_2487 nbt) {
        super.method_5749(nbt);
        if (nbt.method_10545("Sm64Kind")) setKind(nbt.method_10558("Sm64Kind"));
    }
}
