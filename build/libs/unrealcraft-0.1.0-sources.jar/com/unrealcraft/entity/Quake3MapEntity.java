package com.unrealcraft.entity;

import com.unrealcraft.ModEntities;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;

/** Holds a Quake 3 BSP path; client renderer draws the mesh at this entity (sea-level anchor). */
public class Quake3MapEntity extends class_1297 {
    private static final class_2940<String> BSP_PATH =
            class_2945.method_12791(Quake3MapEntity.class, class_2943.field_13326);

    public Quake3MapEntity(class_1299<? extends Quake3MapEntity> type, class_1937 world) {
        super(type, world);
        field_5960 = true;
        method_5875(true);
        // Must NOT be invisible — EntityRenderer skips invisible entities for normal players
        method_5648(false);
        field_5985 = true;
    }

    public Quake3MapEntity(class_1937 world, String path) {
        this(ModEntities.Q3_MAP, world);
        setBspPath(path);
    }

    public String getBspPath() { return field_6011.method_12789(BSP_PATH); }
    public void setBspPath(String p) { field_6011.method_12778(BSP_PATH, p == null ? "" : p); }

    @Override
    protected void method_5693(class_2945.class_9222 b) {
        b.method_56912(BSP_PATH, "");
    }

    @Override
    protected void method_5749(class_2487 n) {
        if (n.method_10545("BspPath")) setBspPath(n.method_10558("BspPath"));
    }

    @Override
    protected void method_5652(class_2487 n) {
        n.method_10582("BspPath", getBspPath());
    }

    @Override
    public void method_5773() {
        super.method_5773();
        // legacy entity from older saves; maps are now drawn client-side
        if (!method_37908().field_9236) method_31472();
    }

    @Override
    public boolean method_5640(double distance) {
        return distance < 512.0 * 512.0;
    }

    @Override
    public boolean method_30948() { return false; }

    @Override
    public boolean method_5863() { return false; }
}
